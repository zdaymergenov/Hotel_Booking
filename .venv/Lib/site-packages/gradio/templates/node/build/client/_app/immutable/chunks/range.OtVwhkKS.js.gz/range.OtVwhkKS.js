function i(n,e,r){n=+n,e=+e,r=(a=arguments.length)<2?(e=n,n=0,1):a<3?1:+r;for(var g=-1,a=Math.max(0,Math.ceil((e-n)/r))|0,h=new Array(a);++g<a;)h[g]=n+g*r;return h}export{i as r};
//# sourceMappingURL=range.OtVwhkKS.js.map
