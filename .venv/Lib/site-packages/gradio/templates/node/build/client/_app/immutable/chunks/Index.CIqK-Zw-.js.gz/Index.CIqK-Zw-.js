import{SvelteComponent as e,init as n,safe_not_equal as o}from"../../../svelte/svelte.js";import"../../../svelte/svelte-submodules.js";class u extends e{constructor(t){super(),n(this,t,null,null,o,{})}}export{u as default};
//# sourceMappingURL=Index.CIqK-Zw-.js.map
