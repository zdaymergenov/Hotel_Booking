import{G as a,f as G}from"./mermaid-parser.core.BLl1nA0H.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-ZV4HHKMB.BHp0Oea3.js.map
