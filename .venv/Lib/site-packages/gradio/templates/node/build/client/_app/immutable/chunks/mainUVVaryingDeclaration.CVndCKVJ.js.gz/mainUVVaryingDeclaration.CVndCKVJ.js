import{j as e}from"./index.BoI39RQH.js";const a="mainUVVaryingDeclaration",r=`#ifdef MAINUV{X}
varying vec2 vMainUV{X};
#endif
`;e.IncludesShadersStore[a]||(e.IncludesShadersStore[a]=r);
//# sourceMappingURL=mainUVVaryingDeclaration.CVndCKVJ.js.map
