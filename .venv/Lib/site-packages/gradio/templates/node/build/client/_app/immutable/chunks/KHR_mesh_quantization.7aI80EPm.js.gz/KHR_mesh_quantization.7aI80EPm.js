import{an as t,ao as i}from"./index.BoI39RQH.js";const s="KHR_mesh_quantization";class o{constructor(n){this.name=s,this.enabled=n.isExtensionUsed(s)}dispose(){}}t(s);i(s,!0,e=>new o(e));export{o as KHR_mesh_quantization};
//# sourceMappingURL=KHR_mesh_quantization.7aI80EPm.js.map
