import{P as c,a as r}from"./mermaid-parser.core.BLl1nA0H.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.DB6_BxEw.js.map
