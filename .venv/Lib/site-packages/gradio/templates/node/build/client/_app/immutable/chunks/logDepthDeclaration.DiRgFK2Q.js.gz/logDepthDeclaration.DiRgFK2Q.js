import{j as e}from"./index.BoI39RQH.js";const r="logDepthDeclaration",t=`#ifdef LOGARITHMICDEPTH
uniform logarithmicDepthConstant: f32;varying vFragmentDepth: f32;
#endif
`;e.IncludesShadersStoreWGSL[r]||(e.IncludesShadersStoreWGSL[r]=t);
//# sourceMappingURL=logDepthDeclaration.DiRgFK2Q.js.map
