import{Y as e,_ as n}from"../chunks/2.BPD7TSJN.js";export{e as component,n as universal};
//# sourceMappingURL=2.CMpgXRgM.js.map
