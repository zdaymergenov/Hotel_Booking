import{r}from"./2.BPD7TSJN.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.DX7nJsd0.js.map
