import{A as c,e as t}from"./mermaid-parser.core.BLl1nA0H.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-O4VJ6CD3.DPbWDwWl.js.map
