import{j as e}from"./index.BoI39RQH.js";const a="mainUVVaryingDeclaration",r=`#ifdef MAINUV{X}
varying vMainUV{X}: vec2f;
#endif
`;e.IncludesShadersStoreWGSL[a]||(e.IncludesShadersStoreWGSL[a]=r);
//# sourceMappingURL=mainUVVaryingDeclaration.SDCC3qCc.js.map
