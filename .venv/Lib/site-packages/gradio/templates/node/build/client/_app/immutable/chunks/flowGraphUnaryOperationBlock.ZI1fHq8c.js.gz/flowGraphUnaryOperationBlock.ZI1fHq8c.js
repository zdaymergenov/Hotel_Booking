import{F as o}from"./flowGraphCachedOperationBlock.CtP7sxiu.js";class p extends o{constructor(a,t,s,e,r){super(t,r),this._operation=s,this._className=e,this.a=this.registerDataInput("a",a)}_doOperation(a){return this._operation(this.a.getValue(a))}getClassName(){return this._className}}export{p as F};
//# sourceMappingURL=flowGraphUnaryOperationBlock.ZI1fHq8c.js.map
