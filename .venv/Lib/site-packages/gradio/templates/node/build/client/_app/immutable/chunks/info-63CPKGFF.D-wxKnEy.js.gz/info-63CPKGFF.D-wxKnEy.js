import{I as r,c as a}from"./mermaid-parser.core.BLl1nA0H.js";export{r as InfoModule,a as createInfoServices};
//# sourceMappingURL=info-63CPKGFF.D-wxKnEy.js.map
